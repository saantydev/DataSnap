<?php

return [
    'host' => 'fedegoo.com.ar',
    'dbname' => 'datasnap',
    'username' => '9895',
    'password' => 'TIGRE.BC.9895',
    'charset' => 'utf8mb4',
    'port' => 3306
];
?>