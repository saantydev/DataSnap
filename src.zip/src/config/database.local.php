<?php
/**
 * Configuración de base de datos para servidor de hosting
 * Este archivo se usa cuando no se puede conectar a la base de datos externa
 */

return [
    'host' => '127.0.0.1',
    'database' => 'u214138677_datasnap',
    'username' => 'u214138677_root',
    'password' => 'TIGRE.BC.9895',
    'charset' => 'utf8mb4',
    'port' => 3306
];